package com.example.springboot.utils;

public class NotFoundClassException extends Exception{
}
