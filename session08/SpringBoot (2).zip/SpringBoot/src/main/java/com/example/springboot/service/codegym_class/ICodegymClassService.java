package com.example.springboot.service.codegym_class;

import com.example.springboot.model.CodegymClass;

import java.util.List;

public interface ICodegymClassService {
    List<CodegymClass> showList();
    CodegymClass findById(Long id);
}
